<?php

use Bitrix\Main\Localization\Loc;

Loc::loadMessages(__FILE__);

$menu = array(
    array(
        'parent_menu' => 'global_menu_content',
        'sort' => 400,
        'text' => Loc::getMessage('ITUA_BASE_MENU_TITLE'),
        'title' => Loc::getMessage('ITUA_BASE_MENU_TITLE'),
        'url' => 'base_index.php',
        'items_id' => 'menu_references',
        'items' => array(
            array(
                'text' => Loc::getMessage('ITUA_BASE_SUBMENU_TITLE'),
                'url' => 'base_index.php?param1=paramval&lang=' . LANGUAGE_ID,
                'more_url' => array('base_index.php?param1=paramval&lang=' . LANGUAGE_ID),
                'title' => Loc::getMessage('ITUA_BASE_SUBMENU_TITLE'),
            ),
        ),
    ),
);

return $menu;
