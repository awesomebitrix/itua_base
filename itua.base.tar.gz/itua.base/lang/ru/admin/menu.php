<?php

$MESS['ITUA_BASE_MENU_TITLE'] = 'Меню';
$MESS['ITUA_BASE_SUBMENU_TITLE'] = 'Подменю';
