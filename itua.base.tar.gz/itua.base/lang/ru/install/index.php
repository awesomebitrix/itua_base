<?php
$MESS['ITUA_BASE_MODULE_NAME'] = 'D7-заготовка';
$MESS['ITUA_BASE_MODULE_DESCRIPTION'] = 'Модуль, D7-заготовка';
$MESS['ITUA_BASE_MODULE_PARTNER_NAME'] = 'Информационные технологии Украины';

