<?php

$MESS['ITUA_BASE_ID'] = 'ID';
$MESS['ITUA_BASE_NAME'] = 'Название';
$MESS['ITUA_BASE_NAME_DEFAULT_VALUE'] = 'Безымянный элемент';
$MESS['ITUA_BASE_IMAGE_SET'] = 'Изображения';

