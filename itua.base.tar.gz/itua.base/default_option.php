<?php

$itua_base_default_option = array(
    'max_image_size' => '500',
);

