<?php

$arModuleVersion = array(
    'VERSION' 		=> '0.1.1',
    'VERSION_DATE' 	=> '2016-11-10'
);